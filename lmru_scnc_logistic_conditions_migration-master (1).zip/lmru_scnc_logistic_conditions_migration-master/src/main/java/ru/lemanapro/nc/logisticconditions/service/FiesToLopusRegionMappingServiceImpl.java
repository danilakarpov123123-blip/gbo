package ru.lemanapro.nc.logisticconditions.service;

import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FiesToLopusRegionMappingServiceImpl implements FiasToLopusRegionMappingService {

    private Map<String, Set<Integer>> map = new HashMap<>();

    @Override
    public Set<Integer> getLopusRegionIdsByFias(String fias) {
        return map.getOrDefault(fias, Collections.emptySet());
    }

    public void init(File file) throws FileNotFoundException {
        CSVReader reader = new CSVReaderBuilder(new FileReader(file))
                .withCSVParser(new CSVParserBuilder()
                        .withSeparator(';')
                        .build())
                .build();

        Iterator<String[]> iterator = reader.iterator();
        String[] headers = iterator.next();
        if (!Objects.equals("Регион", headers[0]) ||
                !Objects.equals("LOPUS", headers[1])) {
            throw new RuntimeException("invalid file format :" + file.getPath());
        }
        iterator.forEachRemaining(arr -> {
            String fias = arr[0];
            Set<Integer> set = Stream.of(arr[1].split(","))
                    .map(i -> Integer.valueOf(i.trim()))
                    .collect(Collectors.toSet());
            map.put(fias, set);
        });
    }
}

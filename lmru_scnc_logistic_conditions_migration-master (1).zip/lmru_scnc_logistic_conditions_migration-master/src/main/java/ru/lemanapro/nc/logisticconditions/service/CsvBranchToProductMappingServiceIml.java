package ru.lemanapro.nc.logisticconditions.service;

import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class CsvBranchToProductMappingServiceIml implements BranchToProductMappingService {

    private Map<Long, Map<String, Set<Long>>> branchesByPartner = new HashMap<>();

    @Override
    public Set<Long> getProductByBranchesAndPartnerId(Long partnerId, List<String> branches) {
        Set<Long> result = new HashSet<>();
        Map<String, Set<Long>> productsByBranches = branchesByPartner.get(partnerId);
        if (productsByBranches == null) {
            return result;
        }
        branches.forEach(i -> {
                    Set<Long> c = productsByBranches.get(i);
                    if (c != null) {
                        result.addAll(c);
                    }
                }
        );
        return result;
    }

    public Set<Long> getProductByBranchAndPartnerId(Long partnerId, String branch) {
        Set<Long> result = new HashSet<>();
        Map<String, Set<Long>> productsByBranches = branchesByPartner.get(partnerId);
        if (productsByBranches == null) {
            return result;
        }
        return productsByBranches.get(branch);
    }


    public void init(File file) throws FileNotFoundException {
        CSVReader reader = new CSVReaderBuilder(new FileReader(file))
                .withCSVParser(new CSVParserBuilder()
                        .withSeparator(',')
                        .build())
                .build();
        List<FileRecord> records = new ArrayList<>();
        Iterator<String[]> iterator = reader.iterator();
        String[] headers = iterator.next();
        if (!Objects.equals("Артикул товара в ЛМ", headers[0]) ||
                !Objects.equals("Идентификатор партнёра", headers[1]) ||
                !Objects.equals("Код отделения", headers[2])) {
            throw new RuntimeException("invalid file format :" + file.getPath());
        }
        iterator.forEachRemaining(arr -> {
            if (arr.length > 2) {
                String[] branches = arr[2].split(",");
                Arrays.stream(branches).forEach(i -> {
                    records.add(new FileRecord(Long.valueOf(arr[0]), i.trim(), Long.valueOf(arr[1])));
                });
            }
        });

        branchesByPartner = records.stream()
                .collect(Collectors.groupingBy(FileRecord::partnerId,
                        Collectors.groupingBy(FileRecord::branch,
                                Collectors.mapping(FileRecord::productId, Collectors.toSet()))));
    }

    private record FileRecord(
            Long productId,
            String branch,
            Long partnerId
    ) {
    }
}

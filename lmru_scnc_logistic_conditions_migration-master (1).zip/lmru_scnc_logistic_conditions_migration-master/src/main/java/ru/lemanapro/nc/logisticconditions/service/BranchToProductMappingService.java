package ru.lemanapro.nc.logisticconditions.service;

import java.util.List;
import java.util.Set;

public interface BranchToProductMappingService {

    Set<Long> getProductByBranchesAndPartnerId(Long partnerId, List<String> branches);
    Set<Long> getProductByBranchAndPartnerId(Long partnerId, String branch);

}

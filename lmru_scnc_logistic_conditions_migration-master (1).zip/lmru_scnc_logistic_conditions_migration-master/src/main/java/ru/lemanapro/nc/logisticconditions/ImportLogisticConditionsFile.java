package ru.lemanapro.nc.logisticconditions;

import ru.lemanapro.nc.logisticconditions.integration.out.rest.lc.LogisticConditionsOutClient;
import ru.lemanapro.nc.logisticconditions.integration.out.rest.lc.LogisticConditionsOutClientImpl;
import ru.lemanapro.nc.logisticconditions.integration.out.rest.lc.dto.SearchRequest;
import ru.lemanapro.nc.logisticconditions.integration.out.rest.lc.dto.SupplierLogisticConditionsDto;
import ru.lemanapro.nc.logisticconditions.service.CsvBranchToProductMappingServiceIml;
import ru.lemanapro.nc.logisticconditions.service.FiesToLopusRegionMappingServiceImpl;
import ru.lemanapro.nc.logisticconditions.service.ImportFileService;
import ru.lemanapro.nc.logisticconditions.service.ParseFileService;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.CountDownLatch;
import java.util.stream.Collectors;

public class ImportLogisticConditionsFile {

    public static String PRODUCT_MAPPING_FILE_PATH = "C:\\Work\\lm\\projects\\nc\\lmru-scnc-logistic-conditions-import\\src\\main\\resources\\1P.csv";
    public static String LOPUS_MAPPING_FILE_PATH = "C:\\Work\\lm\\projects\\nc\\lmru-scnc-logistic-conditions-import\\src\\main\\resources\\lopusMappingSample.csv";
    public static String LOG_CONDITION_DATA_FILE_PATH = "C:\\Work\\lm\\projects\\nc\\lmru-scnc-logistic-conditions-import\\src\\main\\resources\\transit_enriched_v5.xlsx";
    public static String LOG_CONDITIONS_API_URL = "https://scnc-chara-prod.sdip.lmru.tech/logistic-conditions";
    public static String LOG_CONDITIONS_API_USER = "secUser";
    public static String LOG_CONDITIONS_API_PASSWORD = "FghnLkFvkufFlL";
    public static Boolean SAVE_DATA = true;

    public static void main(String[] args) throws IOException {
//        readVars();
        CsvBranchToProductMappingServiceIml branchMapper = new CsvBranchToProductMappingServiceIml();
        branchMapper.init(new File(PRODUCT_MAPPING_FILE_PATH));
        FiesToLopusRegionMappingServiceImpl lopusMapper = new FiesToLopusRegionMappingServiceImpl();
        lopusMapper.init(new File(LOPUS_MAPPING_FILE_PATH));
        ImportFileService importFileService = new ImportFileService(branchMapper, lopusMapper, new ParseFileService());
        List<SupplierLogisticConditionsDto> supplierLogisticConditionsWithProductsDtos = importFileService.importFile(new FileInputStream(LOG_CONDITION_DATA_FILE_PATH));
        Map<String, List<SupplierLogisticConditionsDto>> collect = supplierLogisticConditionsWithProductsDtos.stream()
                .collect(Collectors.groupingBy(i -> i.getSourceId()));
        CountDownLatch countDownLatch = new CountDownLatch(supplierLogisticConditionsWithProductsDtos.size());

        if (SAVE_DATA) {
            LogisticConditionsOutClient client = new LogisticConditionsOutClientImpl(LOG_CONDITIONS_API_URL, LOG_CONDITIONS_API_USER, LOG_CONDITIONS_API_PASSWORD);

            collect.forEach((k, v) -> {
                //get all transit lc from this source, grouped by dest id
                Map<String, List<SupplierLogisticConditionsDto>> destIdMap = client.search(new SearchRequest("LOCATION", k, "TRANSIT"))
                        .getContent().stream().collect(Collectors.groupingBy(i -> i.getDestinationId()));
                //after sort inactive lc will be in start of list
                destIdMap.forEach((key,val) -> {
                    val.sort(Comparator.comparing(i -> i.getValidTo() == null? LocalDate.MAX: i.getValidTo()));
                });

                v.forEach(i -> {
                        List<SupplierLogisticConditionsDto> logConditionForRegion = destIdMap.get(i.getDestinationId());
                        if(logConditionForRegion == null || logConditionForRegion.isEmpty()) {
                            SupplierLogisticConditionsDto created = client.create(i);
                            System.out.println("create : " + created + " product count: " + i.getProductBUReferences().size());
                        }else {
                            SupplierLogisticConditionsDto supplierLogisticConditionsDto = logConditionForRegion.removeLast();
                            i.setId(supplierLogisticConditionsDto.getId());
                            SupplierLogisticConditionsDto updated = client.update(i.getId(), i);
                            System.out.println("updated : " + updated + " product count: " + i.getProductBUReferences().size());
                        }
                    countDownLatch.countDown();
                    System.out.println("left :" + countDownLatch.getCount());
                });

                //make inactive other logistic conditions
                destIdMap.forEach((key, val) -> {
                    val.forEach(i -> {
                        if (i.getValidTo() == null || !i.getValidTo().isBefore(LocalDate.now())) {
                            i.setValidTo(LocalDate.now().minusDays(1));
                            client.update(i.getId(), i);
                        }
                    });
                });

            });
        }

    }


    private static void readVars() {
        String productMappingFile = System.getProperty("migration.input.product-mapping-file");
        if (productMappingFile != null) {
            PRODUCT_MAPPING_FILE_PATH = productMappingFile;
            System.out.println("input dir: " + PRODUCT_MAPPING_FILE_PATH);
        }
        String lopusMappingPath = System.getProperty("migration.input.lopus-mapping-file");
        if (lopusMappingPath != null) {
            LOPUS_MAPPING_FILE_PATH = lopusMappingPath;
            System.out.println("input dir: " + LOPUS_MAPPING_FILE_PATH);
        }
        String logConditionsFilePath = System.getProperty("migration.input.log-conditions-file");
        if (logConditionsFilePath != null) {
            LOG_CONDITION_DATA_FILE_PATH = logConditionsFilePath;
            System.out.println("save result to db:" + LOG_CONDITION_DATA_FILE_PATH);
        }
        String saveFlag = System.getProperty("migration.result.save");
        if (saveFlag != null) {
            SAVE_DATA = Boolean.parseBoolean(saveFlag);
            System.out.println("save result to api:" + SAVE_DATA);
        }
        if (SAVE_DATA) {
            LOG_CONDITIONS_API_URL = System.getProperty("migration.api.url");
            LOG_CONDITIONS_API_USER = System.getProperty("migration.api.username");
            LOG_CONDITIONS_API_PASSWORD = System.getProperty("migration.api.password");
        }
    }

}

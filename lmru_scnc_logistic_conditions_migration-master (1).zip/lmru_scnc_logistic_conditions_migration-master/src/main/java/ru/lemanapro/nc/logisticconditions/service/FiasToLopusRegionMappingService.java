package ru.lemanapro.nc.logisticconditions.service;


import java.util.Set;

public interface FiasToLopusRegionMappingService {

       Set<Integer> getLopusRegionIdsByFias(String fias);
}
